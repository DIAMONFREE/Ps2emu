#pragma once

namespace Hdd
{
	static const uint64 g_sectorSize = 512;
}
