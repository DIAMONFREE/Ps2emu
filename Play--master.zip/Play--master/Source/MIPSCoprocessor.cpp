#include "MIPSCoprocessor.h"

CMIPSCoprocessor::CMIPSCoprocessor(MIPS_REGSIZE nRegSize)
    : CMIPSInstructionFactory(nRegSize)
{
}
