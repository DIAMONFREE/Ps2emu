#pragma once

#include "Types.h"

uint32 FpAddTruncate(uint32, uint32);
